<footer class="footer mt-auto py-3 bg-white border-top">
    <div class="container text-center">
        <span class="text-muted">© 2026 Proyek Kuliah Full-Stack. All rights reserved.</span>
    </div>
</footer><?php /**PATH D:\xampp\htdocs\app_resto\resources\views/layouts/footer.blade.php ENDPATH**/ ?>