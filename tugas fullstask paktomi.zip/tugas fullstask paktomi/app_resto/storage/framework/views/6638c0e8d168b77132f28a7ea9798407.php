

<?php $__env->startSection('content'); ?>
<h1 class="display-6 text-primary">Tambah Menu</h1>
<a href="/menu" class="btn btn-sm btn-outline-secondary mb-3">Kembali</a>

<div v-if="notifikasi" class="alert alert-success">
    {{ notifikasi }}
</div>

<form @submit.prevent="submitForm">
    <div class="mb-3">
        <label class="form-label">Kode</label>
        <input type="text" class="form-control"
               v-model.trim="form.kode" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Nama</label>
        <input type="text" class="form-control"
               v-model.trim="form.nama" required>
    </div>

    <button class="btn btn-primary" type="submit" :disabled="sedangKirim">
        Simpan Menu
    </button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/vuejs/vue.global.js')); ?>"></script>
<script>
const { createApp, ref } = Vue;

createApp({
    setup() {
        const sedangKirim = ref(false);
        const notifikasi = ref(null);
        const form = ref({ kode: '', nama: '' });

        function submitForm() {
            sedangKirim.value = true;
            notifikasi.value = null;

            fetch('/api/create_menu', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(form.value)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Gagal menyimpan menu');
                }
                return response.json();
            })
            .then(response => {
                if (response.status === 'success') {
                    notifikasi.value = 'Menu berhasil disimpan!';
                    form.value = { kode: '', nama: '' };
                }
                sedangKirim.value = false;
            })
            .catch(error => {
                alert(error.message);
                sedangKirim.value = false;
            });
        }

        return { form, sedangKirim, notifikasi, submitForm };
    }
}).mount('#app');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\app_resto\resources\views/add_menu.blade.php ENDPATH**/ ?>