

<?php $__env->startSection('content'); ?>
<a style="text-decoration: none;" href="/"><i class="fi fi-rr-angle-left"></i></i></a>
<div class="d-flex justify-content-between align-items-center">
    <h1 class="display-6 text-primary">Daftar Menu</h1>
    <a href="./add_menu" class="btn btn-sm btn-primary">Tambah Menu</a>
</div>
<hr>

<div v-if="sedangMemuat" class="alert alert-info">Memuat data...</div>
<div v-else-if="pesanEror" class="alert alert-danger">{{ pesanEror }}</div>
<div v-else-if="daftarMenu.length === 0" class="alert alert-warning">
    Belum ada data menu.
</div>

<table v-else class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Kode</th>
            <th>Nama</th>
        </tr>
    </thead>
    <tbody>
        <tr v-for="menu in daftarMenu" :key="menu.id">
            <td>{{ menu.id }}</td>
            <td>{{ menu.kode }}</td>
            <td>{{ menu.nama }}</td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/vuejs/vue.global.js')); ?>"></script>
<script>
const { createApp, ref, onMounted } = Vue;

createApp({
    setup() {
        const daftarMenu = ref([]);
        const sedangMemuat = ref(true);
        const pesanEror = ref(null);

        function ambilDataMenu() {
            fetch('/api/data_menu')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Gagal mengambil data menu');
                    }
                    return response.json();
                })
                .then(data => {
                    daftarMenu.value = data;
                    sedangMemuat.value = false;
                })
                .catch(error => {
                    pesanEror.value = error.message;
                    sedangMemuat.value = false;
                });
        }

        onMounted(() => ambilDataMenu());

        return { daftarMenu, sedangMemuat, pesanEror };
    }
}).mount('#app');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\app_resto\resources\views/menu.blade.php ENDPATH**/ ?>