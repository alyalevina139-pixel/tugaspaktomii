
<?php $__env->startSection('content'); ?>
    <h1 class="display-5 text-primary">Welcome to Resto App!</h1>
    <hr class="my-4 text-secondary opacity-50">
    <div class="lead text-dark">
        <p>Lorem ipsum dolor sit amet...</p>
    </div>
    <div>
        <a href="./product" class="btn btn-sm btn-primary">Daftar Produk</a>
        <a href="./menu" class="btn btn-sm btn-primary">Daftar Menu</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/vuejs/vue.global.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\app_resto\resources\views/home.blade.php ENDPATH**/ ?>