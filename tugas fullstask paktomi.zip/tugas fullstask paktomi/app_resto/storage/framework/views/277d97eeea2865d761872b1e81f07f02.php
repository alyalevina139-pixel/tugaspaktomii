<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-100">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/4.0.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
        <script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    </head>
    <body class="d-flex flex-column h-100 bg-light">
        <main class="flex-shrink-0" id="app">
            <div class="container mt-5">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php echo $__env->yieldContent('modal'); ?>
        </main>

        <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html><?php /**PATH D:\xampp\htdocs\app_resto\resources\views/layouts/app.blade.php ENDPATH**/ ?>